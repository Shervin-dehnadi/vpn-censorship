#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import sys
import uuid
from collections import defaultdict, deque
from datetime import datetime, timezone, timedelta
from pathlib import Path

import pandas as pd
from scapy.all import IP, IPv6, PcapReader, Raw, TCP, UDP  # type: ignore

ROOT = Path("/opt/dpi-lab")
PCAP_DIR = ROOT / "pcap"
EVE_PATH = Path("/var/log/suricata/eve.json")
PROFILE_MAP = ROOT / "ip_profile_map.json"
SERVICE_PORTS = {2083, 2097, 443}
SERVER_BUILD = "xray-core 1.8.24"

PARAMS_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else (ROOT / "config" / "experiment_selected.json")
OUT_CSV = Path(sys.argv[2]) if len(sys.argv) > 2 else (ROOT / "output" / "dpi_lab_dataset_full.csv")
MODE = sys.argv[3] if len(sys.argv) > 3 else "baseline"

UUID_NS = uuid.UUID("2cb93075-2773-4ca1-b2fd-e7abfe66b9a1")


def sha12(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]


def load_json(path: Path, default):
    if path.exists():
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    return default


params = load_json(PARAMS_PATH, {})
profiles = load_json(PROFILE_MAP, {})
feature_cfg = params.get("feature_engineering", {})
smoothing_strength = float(feature_cfg.get("hist_success_smoothing_strength", 5.0))
ema_alpha = float(feature_cfg.get("ema_alpha", 0.2))


def tod_bucket(ts: datetime) -> str:
    h = ts.hour
    if 5 <= h < 12:
        return "morning"
    if 12 <= h < 17:
        return "noon"
    if 17 <= h < 22:
        return "evening"
    return "midnight"


def entropy(buf: bytes) -> float:
    if not buf:
        return 0.0
    counts = defaultdict(int)
    for b in buf:
        counts[b] += 1
    n = len(buf)
    return round(-sum((v / n) * math.log2(v / n) for v in counts.values()), 6)


def ascii_ratio(buf: bytes) -> float:
    if not buf:
        return 0.0
    return round(sum(1 for b in buf if 32 <= b <= 126) / len(buf), 6)


def norm_key(src_ip: str, src_port: int, dst_ip: str, dst_port: int, proto: str):
    if dst_port in SERVICE_PORTS:
        return (src_ip, src_port, dst_ip, dst_port, proto)
    if src_port in SERVICE_PORTS:
        return (dst_ip, dst_port, src_ip, src_port, proto)
    return None


def packet_dir(sport: int, dport: int):
    if dport in SERVICE_PORTS:
        return "up"
    if sport in SERVICE_PORTS:
        return "down"
    return None


def bucket_dns_name(q: str) -> str:
    q = (q or "").lower()
    if not q:
        return "not_observed"
    if "apple" in q:
        return "apple_front"
    if "ourbluesky" in q:
        return "ourbluesky_front"
    return "other_" + sha12(q)


def ip_profile(ip: str):
    p = profiles.get(ip, {})
    return {
        "src_asn": p.get("src_asn", "UNKNOWN"),
        "src_cc": p.get("src_cc", "UNKNOWN"),
        "src_isp": p.get("src_isp", "UNKNOWN"),
        "prob_cgnat": bool(p.get("prob_cgnat", False)),
    }


PORT_META = {
    2083: {"protocol_label": "vless-tcp-no-tls", "flow": "not_applicable"},
    2097: {"protocol_label": "vless-tcp-tls", "flow": "not_applicable"},
    443: {"protocol_label": "vless-reality", "flow": "xtls-rprx-vision"},
}

eve_meta = defaultdict(
    lambda: {
        "tls_event_ts": None,
        "alpn_negotiated": "not_observed",
        "tls_version": "not_observed",
        "cipher_chosen": "not_observed",
        "ja3": "not_observed",
        "ja4": "not_observed",
        "utls_inferred": "unknown",
        "alpn_offered_set_hash": "not_observed",
        "tls_alert_desc": "not_observed",
        "signature_based_match": 0,
        "sni_bucket": "not_observed",
        "cdn_vendor": "unknown",
        "dest_bucket": "not_observed",
    }
)

dns_by_flow = {}

if EVE_PATH.exists():
    with EVE_PATH.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue

            src_ip = rec.get("src_ip")
            dst_ip = rec.get("dest_ip")
            src_port = int(rec.get("src_port", 0) or 0)
            dst_port = int(rec.get("dest_port", 0) or 0)
            proto = str(rec.get("proto", "TCP"))

            key = norm_key(src_ip, src_port, dst_ip, dst_port, proto)
            if not key:
                continue

            et = rec.get("event_type")
            event_ts = None
            if "timestamp" in rec:
                try:
                    event_ts = datetime.fromisoformat(str(rec["timestamp"]).replace("Z", "+00:00")).timestamp()
                except Exception:
                    event_ts = None

            if et == "alert":
                eve_meta[key]["signature_based_match"] = 1
                sig = str((rec.get("alert") or {}).get("signature", "") or "")
                if "tls" in sig.lower():
                    eve_meta[key]["tls_alert_desc"] = sig

            elif et == "anomaly":
                app = str(rec.get("app_proto", "") or "")
                if "tls" in app.lower():
                    eve_meta[key]["tls_alert_desc"] = str((rec.get("anomaly") or {}).get("event", "tls_anomaly"))

            elif et == "tls":
                tls = rec.get("tls") or {}
                if eve_meta[key]["tls_event_ts"] is None and event_ts is not None:
                    eve_meta[key]["tls_event_ts"] = event_ts

                ja3 = tls.get("ja3")
                if isinstance(ja3, dict):
                    ja3 = ja3.get("hash")

                ja4 = tls.get("ja4")
                sni = str(tls.get("sni") or "")
                alpn = tls.get("alpn") or "not_observed"
                client_alpns = tls.get("client_alpns")

                eve_meta[key]["alpn_negotiated"] = str(alpn) if alpn else "not_observed"
                eve_meta[key]["tls_version"] = str(tls.get("version") or "not_observed")
                eve_meta[key]["cipher_chosen"] = str(tls.get("cipher") or "not_observed")
                eve_meta[key]["ja3"] = str(ja3) if ja3 else "not_observed"
                eve_meta[key]["ja4"] = str(ja4) if ja4 else "not_observed"
                eve_meta[key]["utls_inferred"] = "unknown" if (ja3 or ja4) else "not_observed"

                if isinstance(client_alpns, list) and client_alpns:
                    eve_meta[key]["alpn_offered_set_hash"] = sha12(",".join(map(str, client_alpns)))
                elif alpn and alpn != "not_observed":
                    eve_meta[key]["alpn_offered_set_hash"] = sha12(str(alpn))

                eve_meta[key]["sni_bucket"] = bucket_dns_name(sni)
                eve_meta[key]["dest_bucket"] = eve_meta[key]["sni_bucket"]

                low = sni.lower()
                if "apple" in low:
                    eve_meta[key]["cdn_vendor"] = "Apple"
                elif "ourbluesky" in low:
                    eve_meta[key]["cdn_vendor"] = "Origin"
                elif "cloudflare" in low:
                    eve_meta[key]["cdn_vendor"] = "Cloudflare"
                elif "google" in low:
                    eve_meta[key]["cdn_vendor"] = "Google"
                elif "akamai" in low:
                    eve_meta[key]["cdn_vendor"] = "Akamai"

            elif et == "dns":
                dns = rec.get("dns") or {}
                q = str(dns.get("rrname") or dns.get("query") or "")
                dns_key = (src_ip, dst_ip)
                dns_by_flow[dns_key] = {
                    "dns_qname_bucket": bucket_dns_name(q),
                    "dns_rcode": dns.get("rcode", "not_observed"),
                    "dns_ttl_s": dns.get("ttl", "not_observed"),
                }

sessions = {}

for pcap in sorted(PCAP_DIR.glob("*.pcap")):
    with PcapReader(str(pcap)) as reader:
        for pkt in reader:
            ip = pkt.getlayer(IP) or pkt.getlayer(IPv6)
            l4 = pkt.getlayer(TCP) or pkt.getlayer(UDP)
            if ip is None or l4 is None:
                continue

            src_ip = ip.src
            dst_ip = ip.dst
            src_port = int(getattr(l4, "sport", 0))
            dst_port = int(getattr(l4, "dport", 0))
            proto = "TCP" if pkt.haslayer(TCP) else "UDP"

            key = norm_key(src_ip, src_port, dst_ip, dst_port, proto)
            if not key:
                continue

            direction = packet_dir(src_port, dst_port)
            if direction is None:
                continue

            ts = float(pkt.time)

            if key not in sessions:
                sessions[key] = {
                    "src_ip": src_ip,
                    "dst_ip": dst_ip,
                    "first_ts": ts,
                    "last_ts": ts,
                    "syn_ts": None,
                    "first_server_payload_ts": None,
                    "sizes": [],
                    "iats": [],
                    "prev_ts": None,
                    "bytes_up": 0,
                    "bytes_down": 0,
                    "payload_sample": bytearray(),
                    "payload_bytes": 0,
                    "header_bytes": 0,
                    "tcp_rst_seen": False,
                    "syn_count": 0,
                    "retransmissions": 0,
                    "seq_seen": set(),
                    "ttl_sum": 0.0,
                    "ttl_n": 0,
                    "fragmentation_seen": False,
                }

            s = sessions[key]
            s["last_ts"] = ts

            size = len(bytes(pkt))
            s["sizes"].append(size)

            if s["prev_ts"] is not None:
                s["iats"].append((ts - s["prev_ts"]) * 1000.0)
            s["prev_ts"] = ts

            if pkt.haslayer(IP):
                s["ttl_sum"] += pkt[IP].ttl
                s["ttl_n"] += 1
                if pkt[IP].flags.MF or pkt[IP].frag > 0:
                    s["fragmentation_seen"] = True
            elif pkt.haslayer(IPv6):
                s["ttl_sum"] += pkt[IPv6].hlim
                s["ttl_n"] += 1

            payload_len = 0
            if pkt.haslayer(Raw):
                payload = bytes(pkt[Raw].load)
                payload_len = len(payload)
                if len(s["payload_sample"]) < 512:
                    need = 512 - len(s["payload_sample"])
                    s["payload_sample"].extend(payload[:need])

            if pkt.haslayer(TCP):
                flags = int(pkt[TCP].flags)
                ip_h = pkt[IP].ihl * 4 if pkt.haslayer(IP) else 40
                tcp_h = pkt[TCP].dataofs * 4
                hdr = ip_h + tcp_h

                if direction == "up" and (flags & 0x02) and not (flags & 0x10):
                    s["syn_count"] += 1
                    if s["syn_ts"] is None:
                        s["syn_ts"] = ts

                if flags & 0x04:
                    s["tcp_rst_seen"] = True

                seq_sig = (direction, int(pkt[TCP].seq), payload_len)
                if payload_len > 0 and seq_sig in s["seq_seen"]:
                    s["retransmissions"] += 1
                else:
                    s["seq_seen"].add(seq_sig)
            else:
                ip_h = pkt[IP].ihl * 4 if pkt.haslayer(IP) else 40
                hdr = ip_h + 8

            s["header_bytes"] += hdr
            s["payload_bytes"] += payload_len

            if direction == "up":
                s["bytes_up"] += size
            else:
                s["bytes_down"] += size
                if payload_len > 0 and s["first_server_payload_ts"] is None:
                    s["first_server_payload_ts"] = ts

rows = []

for key, s in sorted(sessions.items(), key=lambda kv: kv[1]["first_ts"]):
    src_ip, src_port, dst_ip, service_port, proto = key
    ts0 = datetime.fromtimestamp(s["first_ts"], timezone.utc)
    em = eve_meta[key]
    prof = ip_profile(src_ip)
    dns = dns_by_flow.get(
        (src_ip, dst_ip),
        {
            "dns_qname_bucket": "not_observed",
            "dns_rcode": "not_observed",
            "dns_ttl_s": "not_observed",
        },
    )

    syn_ts = s["syn_ts"] if s["syn_ts"] is not None else s["first_ts"]

    tt_handshake_ms = None
    ttfb_ms = None
    timing_basis = "not_observed"

    if service_port == 2097:
        if em["tls_event_ts"] is not None:
            delta = (em["tls_event_ts"] - syn_ts) * 1000.0
            if delta >= 0:
                tt_handshake_ms = round(delta, 6)
                timing_basis = "suricata_tls_event_proxy"
                if s["first_server_payload_ts"] is not None and s["first_server_payload_ts"] >= em["tls_event_ts"]:
                    ttfb_ms = round((s["first_server_payload_ts"] - em["tls_event_ts"]) * 1000.0, 6)
            elif s["first_server_payload_ts"] is not None:
                tt_handshake_ms = round((s["first_server_payload_ts"] - syn_ts) * 1000.0, 6)
                timing_basis = "fallback_first_server_payload_proxy"
        elif s["first_server_payload_ts"] is not None:
            tt_handshake_ms = round((s["first_server_payload_ts"] - syn_ts) * 1000.0, 6)
            timing_basis = "first_server_payload_proxy"

    elif service_port == 443:
        if s["first_server_payload_ts"] is not None:
            tt_handshake_ms = round((s["first_server_payload_ts"] - syn_ts) * 1000.0, 6)
            timing_basis = "first_server_payload_proxy"

    else:  # 2083
        if s["first_server_payload_ts"] is not None:
            ttfb_ms = round((s["first_server_payload_ts"] - syn_ts) * 1000.0, 6)
            timing_basis = "first_server_payload_proxy"

    if tt_handshake_ms is not None and tt_handshake_ms < 0:
        tt_handshake_ms = None
    if ttfb_ms is not None and ttfb_ms < 0:
        ttfb_ms = None

    if service_port == 443:
        sni_bucket = em["sni_bucket"] if em["sni_bucket"] != "not_observed" else "apple_front"
        cdn_vendor = em["cdn_vendor"] if em["cdn_vendor"] != "unknown" else "Apple"
        dest_bucket = em["dest_bucket"] if em["dest_bucket"] != "not_observed" else "apple_front"

        alpn_negotiated = em["alpn_negotiated"] if em["alpn_negotiated"] != "not_observed" else "not_observable_passthrough"
        tls_version = em["tls_version"] if em["tls_version"] != "not_observed" else "not_observable_passthrough"
        cipher_chosen = em["cipher_chosen"] if em["cipher_chosen"] != "not_observed" else "not_observable_passthrough"
        ja3 = em["ja3"] if em["ja3"] != "not_observed" else "not_observable_passthrough"
        ja4 = em["ja4"] if em["ja4"] != "not_observed" else "not_observable_passthrough"
        utls_inferred = em["utls_inferred"] if em["utls_inferred"] != "unknown" else "not_observable_passthrough"
        alpn_offered_set_hash = em["alpn_offered_set_hash"] if em["alpn_offered_set_hash"] != "not_observed" else "not_observable_passthrough"
        tls_alert_desc = em["tls_alert_desc"]

    elif service_port == 2097:
        sni_bucket = em["sni_bucket"]
        cdn_vendor = em["cdn_vendor"]
        dest_bucket = em["dest_bucket"]
        alpn_negotiated = em["alpn_negotiated"]
        tls_version = em["tls_version"]
        cipher_chosen = em["cipher_chosen"]
        ja3 = em["ja3"]
        ja4 = em["ja4"]
        utls_inferred = em["utls_inferred"]
        alpn_offered_set_hash = em["alpn_offered_set_hash"]
        tls_alert_desc = em["tls_alert_desc"]

    else:  # 2083
        sni_bucket = "not_applicable"
        cdn_vendor = "not_applicable"
        dest_bucket = "not_applicable"
        alpn_negotiated = "not_applicable"
        tls_version = "not_applicable"
        cipher_chosen = "not_applicable"
        ja3 = "not_applicable"
        ja4 = "not_applicable"
        utls_inferred = "not_applicable"
        alpn_offered_set_hash = "not_applicable"
        tls_alert_desc = "not_applicable"

    sizes = s["sizes"]
    iats = s["iats"]
    dur_s = round(s["last_ts"] - s["first_ts"], 6)

    packet_size_mean = round(statistics.mean(sizes), 6) if sizes else None
    packet_size_std = round(statistics.pstdev(sizes), 6) if len(sizes) > 1 else 0.0
    packet_size_p95 = round(float(pd.Series(sizes).quantile(0.95)), 6) if sizes else None
    iat_mean = round(statistics.mean(iats), 6) if iats else None
    iat_std = round(statistics.pstdev(iats), 6) if len(iats) > 1 else 0.0
    throughput_kbps = round((s["bytes_down"] * 8 / 1000.0) / max(dur_s, 0.001), 6) if dur_s > 0 else 0.0
    ttl_mean = round(s["ttl_sum"] / s["ttl_n"], 6) if s["ttl_n"] else None

    sample = bytes(s["payload_sample"])
    byte_bins = [0.0] * 8
    if sample:
        counts = [0] * 8
        for b in sample:
            counts[min(b // 32, 7)] += 1
        total = len(sample)
        byte_bins = [round(x / total, 6) for x in counts]

    label_thresholds = params.get("label_thresholds", {})
    hs_by_port = label_thresholds.get("max_handshake_ms_by_port", {})
    min_bytes_by_port = label_thresholds.get("min_bytes_down_by_port", {})

    if MODE == "baseline":
        label_success = int((not s["tcp_rst_seen"]) and (s["bytes_down"] > 0))
    else:
        max_hs = hs_by_port.get(str(service_port))
        min_bytes = min_bytes_by_port.get(str(service_port), 0)

        if s["tcp_rst_seen"] or s["bytes_down"] < int(min_bytes):
            label_success = 0
        elif service_port in (2097, 443):
            if max_hs is None:
                label_success = int(tt_handshake_ms is not None and tt_handshake_ms >= 0)
            else:
                label_success = int(tt_handshake_ms is not None and tt_handshake_ms >= 0 and tt_handshake_ms <= float(max_hs))
        else:
            label_success = 1

    if s["tcp_rst_seen"]:
        censor_action = "tcp_reset"
    elif s["syn_count"] > 1 and s["bytes_down"] == 0:
        censor_action = "drop"
    elif label_success == 0 and s["bytes_down"] > 0:
        censor_action = "throttle_or_partial"
    elif label_success == 1:
        censor_action = "allow"
    else:
        censor_action = "unknown"

    rows.append(
        {
            "experiment_id": params.get("experiment_id", "unknown"),
            "session_id": str(uuid.uuid5(UUID_NS, f"{src_ip}:{src_port}:{service_port}:{proto}:{s['first_ts']:.6f}")),
            "timestamp_utc": ts0.isoformat().replace("+00:00", "Z"),
            "tod_bucket": tod_bucket(ts0),
            "dow": ts0.weekday(),
            "src_asn": prof["src_asn"],
            "src_cc": prof["src_cc"],
            "src_isp": prof["src_isp"],
            "ip_version": "ipv6" if ":" in src_ip else "ipv4",
            "prob_cgnat": bool(prof["prob_cgnat"]),
            "port": service_port,
            "protocol_label": PORT_META[service_port]["protocol_label"],
            "flow": PORT_META[service_port]["flow"],
            "server_build": SERVER_BUILD,
            "alpn_negotiated": alpn_negotiated,
            "tls_version": tls_version,
            "cipher_chosen": cipher_chosen,
            "ja3": ja3,
            "ja4": ja4,
            "utls_inferred": utls_inferred,
            "alpn_offered_set_hash": alpn_offered_set_hash,
            "sni_bucket": sni_bucket,
            "cdn_vendor": cdn_vendor,
            "dest_bucket": dest_bucket,
            "tcp_rst_seen": int(s["tcp_rst_seen"]),
            "syn_retries": max(s["syn_count"] - 1, 0),
            "tls_alert_desc": tls_alert_desc,
            "retransmissions": s["retransmissions"],
            "tt_handshake_ms": tt_handshake_ms,
            "ttfb_ms": ttfb_ms,
            "timing_basis": timing_basis,
            "throughput_kbps": throughput_kbps,
            "session_duration_s": dur_s,
            "bytes_up": s["bytes_up"],
            "bytes_down": s["bytes_down"],
            "signature_based_match": em["signature_based_match"],
            "protocol_state_tracking": (
                "reset"
                if s["tcp_rst_seen"]
                else (
                    "timeout"
                    if max(s["syn_count"] - 1, 0) > 0 and s["bytes_down"] == 0
                    else ("complete" if label_success == 1 else "partial")
                )
            ),
            "heuristic_behavior_score": round(
                (
                    int(s["tcp_rst_seen"])
                    + int(max(s["syn_count"] - 1, 0) > 0)
                    + int(s["retransmissions"] > 0)
                )
                / 3.0,
                6,
            ),
            "packet_size_mean": packet_size_mean,
            "packet_size_std": packet_size_std,
            "packet_size_p95": packet_size_p95,
            "interarrival_mean_ms": iat_mean,
            "interarrival_std_ms": iat_std,
            "flow_duration_ms": round(dur_s * 1000.0, 6),
            "byte_entropy": entropy(sample),
            "ascii_ratio_initial32": ascii_ratio(sample[:32]),
            "byte_freq_bin_00_31": byte_bins[0],
            "byte_freq_bin_32_63": byte_bins[1],
            "byte_freq_bin_64_95": byte_bins[2],
            "byte_freq_bin_96_127": byte_bins[3],
            "byte_freq_bin_128_159": byte_bins[4],
            "byte_freq_bin_160_191": byte_bins[5],
            "byte_freq_bin_192_223": byte_bins[6],
            "byte_freq_bin_224_255": byte_bins[7],
            "payload_to_header_ratio": round(s["payload_bytes"] / max(s["header_bytes"], 1), 6),
            "dns_qname_bucket": dns["dns_qname_bucket"],
            "dns_rcode": dns["dns_rcode"],
            "dns_ttl_s": dns["dns_ttl_s"],
            "ttl_mean": ttl_mean,
            "fragmentation_seen": int(s["fragmentation_seen"]),
            "label_success": label_success,
            "censor_action": censor_action,
        }
    )

df = pd.DataFrame(rows).sort_values("timestamp_utc").reset_index(drop=True)
if df.empty:
    raise SystemExit("No sessions found in PCAP directory")

q33 = float(df["flow_duration_ms"].quantile(1 / 3))
q66 = float(df["flow_duration_ms"].quantile(2 / 3))
bytes_median = float(df["bytes_down"].median())


def classify(row):
    if row["flow_duration_ms"] <= q33:
        return "short_burst"
    if row["flow_duration_ms"] <= q66 or row["bytes_down"] <= bytes_median:
        return "interactive"
    return "bulk_transfer"


df["connection_pattern_bucket"] = df.apply(classify, axis=1)

global_prior = float(df["label_success"].mean()) if len(df) else 0.5
bucket_stats = defaultdict(lambda: [0, 0])
sni_stats = defaultdict(lambda: [0, 0])
port_stats = defaultdict(lambda: [0, 0])
ja3_stats = defaultdict(lambda: [0, 0])

hist_bucket = []
hist_sni = []
hist_port = []
hist_ja3 = []


def smooth(n, succ):
    return round((succ + smoothing_strength * global_prior) / (n + smoothing_strength), 6)


for _, row in df.iterrows():
    bkey = (row["sni_bucket"], row["port"], row["ja3"])
    hist_bucket.append(smooth(*bucket_stats[bkey]))
    hist_sni.append(smooth(*sni_stats[row["sni_bucket"]]))
    hist_port.append(smooth(*port_stats[row["port"]]))
    hist_ja3.append(smooth(*ja3_stats[row["ja3"]]))

    y = int(row["label_success"])
    bucket_stats[bkey][0] += 1
    bucket_stats[bkey][1] += y
    sni_stats[row["sni_bucket"]][0] += 1
    sni_stats[row["sni_bucket"]][1] += y
    port_stats[row["port"]][0] += 1
    port_stats[row["port"]][1] += y
    ja3_stats[row["ja3"]][0] += 1
    ja3_stats[row["ja3"]][1] += y

df["hist_success_rate_by_bucket"] = hist_bucket
df["hist_success_rate_by_sni"] = hist_sni
df["hist_success_rate_by_port"] = hist_port
df["hist_success_rate_by_ja3"] = hist_ja3

windows = defaultdict(deque)
ema_values = []

for _, row in df.iterrows():
    ts = datetime.fromisoformat(str(row["timestamp_utc"]).replace("Z", "+00:00"))
    port = int(row["port"])
    throughput = float(row["throughput_kbps"])

    w = windows[port]
    cutoff = ts - timedelta(hours=24)
    while w and w[0][0] < cutoff:
        w.popleft()

    if w:
        ema = round(ema_alpha * throughput + (1.0 - ema_alpha) * w[-1][2], 6)
    else:
        ema = round(throughput, 6)

    w.append((ts, throughput, ema))
    ema_values.append(ema)

df["ema_throughput_kbps_24h"] = ema_values

df["ratio_handshake_totaldelay"] = df.apply(
    lambda row: round(float(row["tt_handshake_ms"]) / float(row["ttfb_ms"]), 6)
    if pd.notna(row["tt_handshake_ms"]) and pd.notna(row["ttfb_ms"]) and float(row["ttfb_ms"]) > 0
    else None,
    axis=1,
)

df["ratio_handshake_session"] = df.apply(
    lambda row: round(float(row["tt_handshake_ms"]) / float(row["session_duration_s"] * 1000), 6)
    if pd.notna(row["tt_handshake_ms"]) and pd.notna(row["session_duration_s"]) and float(row["session_duration_s"]) > 0
    else None,
    axis=1,
)

df["onehot_morning"] = (df["tod_bucket"] == "morning").astype(int)
df["onehot_noon"] = (df["tod_bucket"] == "noon").astype(int)
df["onehot_evening"] = (df["tod_bucket"] == "evening").astype(int)
df["onehot_midnight"] = (df["tod_bucket"] == "midnight").astype(int)

OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
df.to_csv(OUT_CSV, index=False, quoting=csv.QUOTE_MINIMAL)

print(f"Wrote {len(df)} rows to {OUT_CSV}")