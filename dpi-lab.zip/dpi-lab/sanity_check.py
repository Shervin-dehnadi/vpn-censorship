#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = {
    "experiment_id", "session_id", "timestamp_utc", "port", "protocol_label",
    "tcp_rst_seen", "syn_retries", "retransmissions", "throughput_kbps",
    "bytes_up", "bytes_down", "label_success", "censor_action",
    "hist_success_rate_by_bucket", "hist_success_rate_by_sni",
    "hist_success_rate_by_port", "hist_success_rate_by_ja3",
    "ema_throughput_kbps_24h"
}

def fail(msg: str):
    print(f"SANITY CHECK FAILED: {msg}", file=sys.stderr)
    raise SystemExit(1)

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 sanity_check_rebuilt.py /path/to/dataset.csv", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    if not path.exists():
        fail(f"File not found: {path}")
    df = pd.read_csv(path, low_memory=False)
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        fail(f"Missing required columns: {sorted(missing)}")
    if df.empty:
        fail("Dataset is empty")
    if not df["session_id"].is_unique:
        fail("session_id must be unique")
    if not df["port"].isin([2083, 2097, 443]).all():
        fail("Unexpected port values detected")
    if not df["label_success"].isin([0,1]).all():
        fail("label_success must be 0/1")
    if (df["throughput_kbps"] < 0).any():
        fail("throughput_kbps contains negative values")
    if (df["bytes_up"] < 0).any() or (df["bytes_down"] < 0).any():
        fail("byte counters cannot be negative")
    if (df["syn_retries"] < 0).any() or (df["retransmissions"] < 0).any():
        fail("syn_retries/retransmissions must be non-negative")
    if "tt_handshake_ms" in df.columns and (df["tt_handshake_ms"].dropna() < 0).any():
        fail("negative tt_handshake_ms found")
    if "ttfb_ms" in df.columns and (df["ttfb_ms"].dropna() < 0).any():
        fail("negative ttfb_ms found")
    ratio = df["ratio_handshake_totaldelay"].dropna() if "ratio_handshake_totaldelay" in df.columns else pd.Series(dtype=float)
    if not ratio.empty and ratio.nunique() == 1:
        fail("ratio_handshake_totaldelay is constant")
    for col in ("hist_success_rate_by_bucket", "hist_success_rate_by_sni", "hist_success_rate_by_port", "hist_success_rate_by_ja3"):
        vals = df[col].dropna()
        if ((vals < 0) | (vals > 1)).any():
            fail(f"{col} contains values outside [0,1]")
    print(f"Rows: {len(df)}")
    print(f"Columns: {len(df.columns)}")
    print("\nPort distribution:")
    print(df["port"].value_counts().sort_index().to_string())
    print("\nLabel success distribution:")
    print(df["label_success"].value_counts().sort_index().to_string())
    print("\nField completion:")
    for col in df.columns:
        print(f"{col}: {round(df[col].notna().mean()*100,2)}%")
    print("\nSANITY CHECK PASSED")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
