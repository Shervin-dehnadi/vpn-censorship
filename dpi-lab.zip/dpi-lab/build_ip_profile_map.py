#!/usr/bin/env python3
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import requests
from scapy.all import IP, IPv6, TCP, UDP, PcapReader  # type: ignore

PCAP_DIR = Path("/opt/dpi-lab/pcap")
OUT = Path("/opt/dpi-lab/ip_profile_map.json")
SERVICE_PORTS = {2083, 2097, 443}

IPINFO_URL = "https://ipinfo.io/{ip}/json"
REQUEST_TIMEOUT = 3
REQUEST_SLEEP_SECONDS = 0.35


def client_ip(src: str, sport: int, dst: str, dport: int) -> str | None:
    if dport in SERVICE_PORTS:
        return src
    if sport in SERVICE_PORTS:
        return dst
    return None


def load_existing_cache(path: Path) -> dict[str, dict[str, Any]]:
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def extract_client_ips() -> set[str]:
    ips: set[str] = set()

    for pcap in sorted(PCAP_DIR.glob("*.pcap")):
        with PcapReader(str(pcap)) as reader:
            for pkt in reader:
                ip = pkt.getlayer(IP) or pkt.getlayer(IPv6)
                l4 = pkt.getlayer(TCP) or pkt.getlayer(UDP)
                if ip is None or l4 is None:
                    continue

                cip = client_ip(
                    ip.src,
                    int(getattr(l4, "sport", 0)),
                    ip.dst,
                    int(getattr(l4, "dport", 0)),
                )
                if cip:
                    ips.add(cip)

    return ips


def fetch_profile(ip: str) -> dict[str, Any]:
    profile = {
        "src_asn": "UNKNOWN",
        "src_cc": "UNKNOWN",
        "src_isp": "UNKNOWN",
        "prob_cgnat": False,
    }

    try:
        resp = requests.get(IPINFO_URL.format(ip=ip), timeout=REQUEST_TIMEOUT)
        data = resp.json() if resp.ok else {}

        org = data.get("org")
        country = data.get("country")

        if org:
            profile["src_asn"] = str(org)
            profile["src_isp"] = str(org)

        if country:
            profile["src_cc"] = str(country)

        # conservative heuristic only; do not invent values
        lowered = str(org or "").lower()
        if any(keyword in lowered for keyword in ["mobile", "wireless", "cellular"]):
            profile["prob_cgnat"] = True

    except Exception:
        pass

    return profile


def main() -> None:
    if not PCAP_DIR.exists():
        raise SystemExit(f"PCAP directory not found: {PCAP_DIR}")

    ips = extract_client_ips()
    if not ips:
        raise SystemExit("No client IPs found in PCAP directory.")

    existing = load_existing_cache(OUT)
    profiles: dict[str, dict[str, Any]] = dict(existing)

    new_ips = [ip for ip in sorted(ips) if ip not in profiles]

    print(f"Found {len(ips)} client IPs in PCAPs.")
    print(f"Existing cached profiles: {len(existing)}")
    print(f"New IPs to enrich: {len(new_ips)}")

    for idx, ip in enumerate(new_ips, start=1):
        profiles[ip] = fetch_profile(ip)
        if idx % 10 == 0 or idx == len(new_ips):
            print(f"Processed {idx}/{len(new_ips)} new IPs...", flush=True)
        time.sleep(REQUEST_SLEEP_SECONDS)

    OUT.write_text(json.dumps(profiles, indent=2), encoding="utf-8")
    print(f"Wrote {OUT} with {len(profiles)} profiles")


if __name__ == "__main__":
    main()