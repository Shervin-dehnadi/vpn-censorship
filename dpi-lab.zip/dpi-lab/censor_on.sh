#!/usr/bin/env bash
set -euo pipefail
CONFIG_PATH="${1:-experiment_selected.json}"
IFACE=$(ip route get 1.1.1.1 | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')
read_json() {
  python3 - "$CONFIG_PATH" "$1" <<'PY'
import json, sys
with open(sys.argv[1], 'r', encoding='utf-8') as f:
    obj = json.load(f)
cur = obj
for part in sys.argv[2].split('.'):
    cur = cur[part]
print(cur)
PY
}
DROP_PROB=$(read_json "censorship.2083.drop_probability")
RST_PROB=$(read_json "censorship.2097.rst_probability")
DELAY_MS=$(read_json "censorship.443.delay_ms")
DELAY_JITTER_MS=$(read_json "censorship.443.delay_jitter_ms")
LOSS_PERCENT=$(read_json "censorship.443.loss_percent")
REORDER_PERCENT=$(read_json "censorship.443.reorder_percent")
REORDER_CORRELATION_PERCENT=$(read_json "censorship.443.reorder_correlation_percent")
sudo iptables -N DPI_SIM 2>/dev/null || true
sudo iptables -F DPI_SIM
for p in 2083 2097 443; do
  sudo iptables -C INPUT -p tcp --dport "$p" -j DPI_SIM 2>/dev/null || sudo iptables -I INPUT -p tcp --dport "$p" -j DPI_SIM
done
sudo iptables -A DPI_SIM -p tcp --dport 2083 -m conntrack --ctstate NEW -m statistic --mode random --probability "$DROP_PROB" -j DROP
sudo iptables -A DPI_SIM -p tcp --dport 2097 -m conntrack --ctstate NEW -m statistic --mode random --probability "$RST_PROB" -j REJECT --reject-with tcp-reset
sudo tc qdisc del dev "$IFACE" root 2>/dev/null || true
sudo tc qdisc add dev "$IFACE" root netem delay "${DELAY_MS}ms" "${DELAY_JITTER_MS}ms" loss "${LOSS_PERCENT}%" reorder "${REORDER_PERCENT}%" "${REORDER_CORRELATION_PERCENT}%"
echo "CENSOR ON on ${IFACE} using ${CONFIG_PATH}"
