#!/usr/bin/env python3
from __future__ import annotations

import itertools
import json
import math
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

ROOT = Path("/opt/dpi-lab")
CONFIG_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else (ROOT / "experiment_params.json")
OUTPUT_DIR = ROOT / "experiments"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: Path, obj: dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def run_cmd(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    print("RUN:", " ".join(map(str, args)), flush=True)
    return subprocess.run(args, cwd=cwd, check=True)


def build_combinations(cfg: dict[str, Any]) -> list[tuple[Any, ...]]:
    c = cfg["censorship"]
    fe = cfg.get("feature_engineering", {})

    combos = list(
        itertools.product(
            c["2083"]["drop_probability_range"],
            c["2097"]["rst_probability_range"],
            c["443"]["delay_ms_range"],
            c["443"]["delay_jitter_ms_range"],
            c["443"]["loss_percent_range"],
            c["443"]["reorder_percent_range"],
            c["443"]["reorder_correlation_percent_range"],
            fe.get("ema_alpha_range", [0.2]),
        )
    )

    # Optional limiter to avoid huge runs
    max_experiments = int(cfg.get("execution", {}).get("max_experiments", 0) or 0)
    if max_experiments > 0:
        combos = combos[:max_experiments]

    return combos


def make_selected(cfg: dict[str, Any], combo: tuple[Any, ...], exp_id: str) -> dict[str, Any]:
    drop, rst, delay, jitter, loss, reorder, reorder_corr, alpha = combo

    return {
        "experiment_id": exp_id,
        "capture": cfg.get(
            "capture",
            {
                "baseline_duration_seconds": 60,
                "censored_duration_seconds": 60,
            },
        ),
        "censorship": {
            "2083": {"drop_probability": drop},
            "2097": {"rst_probability": rst},
            "443": {
                "delay_ms": delay,
                "delay_jitter_ms": jitter,
                "loss_percent": loss,
                "reorder_percent": reorder,
                "reorder_correlation_percent": reorder_corr,
            },
        },
        "feature_engineering": {
            "ema_alpha": alpha,
            "hist_success_smoothing_strength": cfg.get("feature_engineering", {}).get(
                "hist_success_smoothing_strength", 5.0
            ),
        },
        "label_thresholds": {
            "max_handshake_ms_by_port": {"2083": None, "2097": None, "443": None},
            "min_bytes_down_by_port": {"2083": None, "2097": None, "443": None},
        },
        "notes": cfg.get("notes", {}),
    }


def start_capture() -> subprocess.Popen:
    return subprocess.Popen(["bash", "run_tcpdump.sh"], cwd=ROOT)


def stop_capture(proc: subprocess.Popen) -> None:
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def derive_thresholds_from_baseline(path: Path, selected_cfg: dict[str, Any]) -> dict[str, Any]:
    df = pd.read_csv(path, low_memory=False)
    if df.empty:
        raise RuntimeError("Baseline dataset is empty.")

    max_hs: dict[str, float | None] = {}
    min_bytes: dict[str, int] = {}

    for port in (2083, 2097, 443):
        subset = df[(df["port"] == port) & (df["label_success"] == 1)]
        if subset.empty:
            raise RuntimeError(
                f"No successful baseline samples for port {port}. "
                f"Generate real uncensored traffic first."
            )

        hs = subset["tt_handshake_ms"].dropna()

        if port == 2083 or hs.empty:
            max_hs[str(port)] = None
        else:
            max_hs[str(port)] = round(float(hs.quantile(0.95)), 3)

        min_bytes[str(port)] = int(math.floor(float(subset["bytes_down"].quantile(0.10))))

    selected_cfg["label_thresholds"] = {
        "max_handshake_ms_by_port": max_hs,
        "min_bytes_down_by_port": min_bytes,
    }
    return selected_cfg


def evaluate_dataset(path: Path) -> float:
    df = pd.read_csv(path, low_memory=False)
    if df.empty:
        return -1.0

    score = 0.0

    success_rate = float(df["label_success"].mean())
    score += 1.0 - abs(0.5 - success_rate)

    if "tt_handshake_ms" in df.columns and df["tt_handshake_ms"].notna().any():
        score += float(df["tt_handshake_ms"].dropna().std(ddof=0) or 0.0)

    score += float(df["tcp_rst_seen"].astype(int).mean())

    pos = df[df["label_success"] == 1]
    neg = df[df["label_success"] == 0]
    if not pos.empty and not neg.empty:
        score += abs(float(pos["throughput_kbps"].mean()) - float(neg["throughput_kbps"].mean()))

    return float(score)


def main() -> None:
    if not CONFIG_PATH.exists():
        raise SystemExit(f"Config file not found: {CONFIG_PATH}")

    cfg = load_json(CONFIG_PATH)
    combos = build_combinations(cfg)

    if not combos:
        raise SystemExit("No experiment combinations found in configuration.")

    capture_cfg = cfg.get("capture", {})
    baseline_duration = int(capture_cfg.get("baseline_duration_seconds", 60))
    censored_duration = int(capture_cfg.get("censored_duration_seconds", 60))

    results: list[dict[str, Any]] = []

    for i, combo in enumerate(combos):
        exp_id = f"exp_{i:04d}_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
        print(f"\n=== STARTING {exp_id} ===", flush=True)

        selected = make_selected(cfg, combo, exp_id)

        pre_path = OUTPUT_DIR / f"{exp_id}.selected.prethreshold.json"
        save_json(pre_path, selected)

        # ---------------------------
        # BASELINE (UNCENSORED) RUN
        # ---------------------------
        run_cmd(["bash", "censor_off.sh"], cwd=ROOT)

        base_cap = start_capture()
        print(
            f"Baseline capture started for {baseline_duration} seconds. "
            f"Generate uncensored client traffic now.",
            flush=True,
        )
        time.sleep(baseline_duration)
        stop_capture(base_cap)

        baseline_csv = OUTPUT_DIR / f"{exp_id}.baseline.csv"
        run_cmd(
            ["python3", "extractor.py", str(pre_path), str(baseline_csv), "baseline"],
            cwd=ROOT,
        )

        # derive thresholds from baseline
        selected = derive_thresholds_from_baseline(baseline_csv, selected)
        final_cfg_path = OUTPUT_DIR / f"{exp_id}.selected.final.json"
        save_json(final_cfg_path, selected)

        # ---------------------------
        # CENSORED RUN
        # ---------------------------
        run_cmd(["bash", "censor_on.sh", str(final_cfg_path)], cwd=ROOT)

        cen_cap = start_capture()
        print(
            f"Censored capture started for {censored_duration} seconds. "
            f"Generate censored client traffic now.",
            flush=True,
        )
        time.sleep(censored_duration)
        stop_capture(cen_cap)

        run_cmd(["bash", "censor_off.sh"], cwd=ROOT)

        final_csv = OUTPUT_DIR / f"{exp_id}.final.csv"
        run_cmd(
            ["python3", "extractor.py", str(final_cfg_path), str(final_csv), "censored"],
            cwd=ROOT,
        )
        run_cmd(["python3", "sanity_check.py", str(final_csv)], cwd=ROOT)

        score = evaluate_dataset(final_csv)

        results.append(
            {
                "experiment_id": exp_id,
                "drop_probability": combo[0],
                "rst_probability": combo[1],
                "delay_ms": combo[2],
                "delay_jitter_ms": combo[3],
                "loss_percent": combo[4],
                "reorder_percent": combo[5],
                "reorder_correlation_percent": combo[6],
                "ema_alpha": combo[7],
                "score": score,
                "selected_config": str(final_cfg_path),
                "baseline_dataset": str(baseline_csv),
                "final_dataset": str(final_csv),
            }
        )

    out = pd.DataFrame(results).sort_values("score", ascending=False).reset_index(drop=True)
    out_path = OUTPUT_DIR / "experiment_results.csv"
    out.to_csv(out_path, index=False)

    print("\nBest configuration:", flush=True)
    print(out.iloc[0].to_string(), flush=True)
    print(f"\nSaved results: {out_path}", flush=True)


if __name__ == "__main__":
    main()